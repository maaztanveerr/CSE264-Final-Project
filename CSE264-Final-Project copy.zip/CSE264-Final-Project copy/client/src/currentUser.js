//change once connected to database w/ login for student/admin

export const currentUser = {
    id: 'dts226',
    name: 'Dylan Serino',
    email: 'dts226@lehigh.edu',
    role: 'admin'
}