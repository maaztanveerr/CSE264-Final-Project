// src/pages/NotFoundPage.jsx
function NotFoundPage() {
  return <h2>404 - Page Not Found</h2>;
}
export default NotFoundPage;